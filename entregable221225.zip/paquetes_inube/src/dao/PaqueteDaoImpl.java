package dao;

import model.EstadoPaquete;
import model.Paquete;
import util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class PaqueteDaoImpl implements PaqueteDao {

    @Override
    public void insertar(Paquete paquete) {

        String sql = """
                INSERT INTO PAQUETES
                (UUID, DESTINATARIO, DIRECCION, ESTADO, FECHA_REGISTRO, ELIMINADO)
                VALUES (?, ?, ?, ?, ?, ?)
                """;

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, paquete.getUuid());
            ps.setString(2, paquete.getDestinatario());
            ps.setString(3, paquete.getDireccion());
            ps.setString(4, paquete.getEstado().name());
            ps.setTimestamp(5, Timestamp.valueOf(paquete.getFechaRegistro()));
            ps.setInt(6, paquete.isEliminado() ? 1 : 0);

            ps.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException("Error al insertar paquete", e);
        }
    }

    @Override
    public Optional<Paquete> buscarPorUuid(String uuid) {

        String sql = """
                SELECT * FROM PAQUETES
                WHERE UUID = ?
                """;

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, uuid);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(mapRow(rs));
                }
            }

        } catch (SQLException e) {
            throw new RuntimeException("Error al buscar paquete por UUID", e);
        }

        return Optional.empty();
    }

    @Override
    public List<Paquete> listarActivos() {

        List<Paquete> paquetes = new ArrayList<>();

        String sql = """
                SELECT * FROM PAQUETES
                WHERE ELIMINADO = 0
                ORDER BY FECHA_REGISTRO
                """;

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                paquetes.add(mapRow(rs));
            }

        } catch (SQLException e) {
            throw new RuntimeException("Error al listar paquetes activos", e);
        }

        return paquetes;
    }

    @Override
    public void actualizar(Paquete paquete) {

        String sql = """
                UPDATE PAQUETES
                SET DESTINATARIO = ?,
                    DIRECCION = ?,
                    ESTADO = ?
                WHERE UUID = ?
                """;

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, paquete.getDestinatario());
            ps.setString(2, paquete.getDireccion());
            ps.setString(3, paquete.getEstado().name());
            ps.setString(4, paquete.getUuid());

            ps.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException("Error al actualizar paquete", e);
        }
    }

    @Override
    public void eliminarLogico(String uuid) {

        String sql = """
                UPDATE PAQUETES
                SET ELIMINADO = 1
                WHERE UUID = ?
                """;

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, uuid);
            ps.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException("Error al aplicar borrado lógico", e);
        }
    }

    // ============================
    // Mapper ResultSet → Paquete
    // ============================

    private Paquete mapRow(ResultSet rs) throws SQLException {

        Paquete paquete = new Paquete();

        paquete.setUuid(rs.getString("UUID"));
        paquete.setDestinatario(rs.getString("DESTINATARIO"));
        paquete.setDireccion(rs.getString("DIRECCION"));
        paquete.setEstado(EstadoPaquete.valueOf(rs.getString("ESTADO")));
        paquete.setFechaRegistro(rs.getTimestamp("FECHA_REGISTRO").toLocalDateTime());
        paquete.setEliminado(rs.getInt("ELIMINADO") == 1);

        return paquete;
    }
}
