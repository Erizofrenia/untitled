package dao;

import model.Paquete;

import java.util.List;
import java.util.Optional;

public interface PaqueteDao {

    void insertar(Paquete paquete);

    Optional<Paquete> buscarPorUuid(String uuid);

    List<Paquete> listarActivos();

    void actualizar(Paquete paquete);

    void eliminarLogico(String uuid);
}
