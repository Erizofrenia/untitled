package model;

public enum EstadoPaquete {
    REGISTRADO,
    EN_TRANSITO,
    ENTREGADO
}
