package model;

import java.time.LocalDateTime;

public class Paquete {

    private String uuid;
    private String destinatario;
    private String direccion;
    private EstadoPaquete estado;
    private LocalDateTime fechaRegistro;
    private boolean eliminado;

    // Constructor vacío (necesario para JDBC y flexibilidad)
    public Paquete() {
    }

    // Constructor completo
    public Paquete(String uuid,
                   String destinatario,
                   String direccion,
                   EstadoPaquete estado,
                   LocalDateTime fechaRegistro,
                   boolean eliminado) {

        this.uuid = uuid;
        this.destinatario = destinatario;
        this.direccion = direccion;
        this.estado = estado;
        this.fechaRegistro = fechaRegistro;
        this.eliminado = eliminado;
    }

    // Getters y Setters

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getDestinatario() {
        return destinatario;
    }

    public void setDestinatario(String destinatario) {
        this.destinatario = destinatario;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public EstadoPaquete getEstado() {
        return estado;
    }

    public void setEstado(EstadoPaquete estado) {
        this.estado = estado;
    }

    public LocalDateTime getFechaRegistro() {
        return fechaRegistro;
    }

    public void setFechaRegistro(LocalDateTime fechaRegistro) {
        this.fechaRegistro = fechaRegistro;
    }

    public boolean isEliminado() {
        return eliminado;
    }

    public void setEliminado(boolean eliminado) {
        this.eliminado = eliminado;
    }

    @Override
    public String toString() {
        return "Paquete {" +
                "UUID='" + uuid + '\'' +
                ", Destinatario='" + destinatario + '\'' +
                ", Dirección='" + direccion + '\'' +
                ", Estado=" + estado +
                ", FechaRegistro=" + fechaRegistro +
                ", Eliminado=" + eliminado +
                '}';
    }
}
