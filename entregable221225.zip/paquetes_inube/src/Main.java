import view.PaqueteView;

public class Main {
    public static void main(String[] args) {
        PaqueteView view = new PaqueteView();

        try {
            view.iniciar();
        } catch (Exception e) {
            System.err.println("❌ Error crítico en la aplicación:");
            System.err.println(e.getMessage());
        } finally {
            System.out.println("Aplicación cerrada correctamente.");
        }
    }
}