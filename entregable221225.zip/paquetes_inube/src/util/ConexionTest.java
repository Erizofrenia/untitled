package util;

import java.sql.Connection;

public class ConexionTest {

    public static void main(String[] args) {
        try (Connection conn = DBConnection.getConnection()) {
            System.out.println("Conexión exitosa a Oracle");
        } catch (Exception e) {
            System.err.println("Error de conexión");
            e.printStackTrace();
        }
    }
}
