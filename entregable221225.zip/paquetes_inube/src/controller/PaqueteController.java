package controller;

import model.Paquete;
import service.PaqueteService;
import service.PaqueteServiceImpl;

import java.util.List;
import java.util.Optional;

public class PaqueteController {

    private final PaqueteService paqueteService;

    public PaqueteController() {
        this.paqueteService = new PaqueteServiceImpl();
    }

    // ============================
    // Crear paquete
    // ============================
    public Paquete crearPaquete(String destinatario, String direccion) {
        try {
            return paqueteService.registrarPaquete(destinatario, direccion);
        } catch (IllegalArgumentException | IllegalStateException e) {
            throw new RuntimeException("No se pudo crear el paquete: " + e.getMessage());
        }
    }

    // ============================
    // Listar paquetes activos
    // ============================
    public List<Paquete> listarPaquetes() {
        try {
            return paqueteService.listarPaquetesActivos();
        } catch (Exception e) {
            throw new RuntimeException("Error al listar paquetes");
        }
    }

    // ============================
    // Buscar por UUID
    // ============================
    public Optional<Paquete> buscarPaquetePorUuid(String uuid) {
        try {
            return paqueteService.buscarPorUuid(uuid);
        } catch (IllegalArgumentException e) {
            throw new RuntimeException("UUID inválido: " + e.getMessage());
        }
    }

    // ============================
    // Actualizar paquete
    // ============================
    public void actualizarPaquete(Paquete paquete) {
        try {
            paqueteService.actualizarPaquete(paquete);
        } catch (IllegalArgumentException | IllegalStateException e) {
            throw new RuntimeException("No se pudo actualizar el paquete: " + e.getMessage());
        }
    }

    // ============================
    // Borrado lógico
    // ============================
    public void eliminarPaqueteLogico(String uuid) {
        try {
            paqueteService.eliminarPaquete(uuid);
        } catch (IllegalArgumentException | IllegalStateException e) {
            throw new RuntimeException("No se pudo eliminar el paquete: " + e.getMessage());
        }
    }
}
