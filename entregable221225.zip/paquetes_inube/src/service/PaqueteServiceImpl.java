package service;

import dao.PaqueteDao;
import dao.PaqueteDaoImpl;
import model.EstadoPaquete;
import model.Paquete;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public class PaqueteServiceImpl implements PaqueteService {

    private final PaqueteDao paqueteDao;

    public PaqueteServiceImpl() {
        this.paqueteDao = new PaqueteDaoImpl();
    }

    // ============================
    // Registrar paquete
    // ============================
    @Override
    public Paquete registrarPaquete(String destinatario, String direccion) {

        validarCampoObligatorio(destinatario, "destinatario");
        validarCampoObligatorio(direccion, "dirección");

        Paquete paquete = new Paquete();
        paquete.setUuid(UUID.randomUUID().toString());
        paquete.setDestinatario(destinatario);
        paquete.setDireccion(direccion);
        paquete.setEstado(EstadoPaquete.REGISTRADO);
        paquete.setFechaRegistro(LocalDateTime.now());
        paquete.setEliminado(false);

        paqueteDao.insertar(paquete);
        return paquete;
    }

    // ============================
    // Buscar paquete
    // ============================
    @Override
    public Optional<Paquete> buscarPorUuid(String uuid) {
        validarCampoObligatorio(uuid, "UUID");
        return paqueteDao.buscarPorUuid(uuid);
    }

    // ============================
    // Listar activos
    // ============================
    @Override
    public List<Paquete> listarPaquetesActivos() {
        return paqueteDao.listarActivos();
    }

    // ============================
    // Actualizar paquete
    // ============================
    @Override
    public void actualizarPaquete(Paquete paquete) {

        if (paquete == null) {
            throw new IllegalArgumentException("El paquete no puede ser nulo");
        }

        validarCampoObligatorio(paquete.getUuid(), "UUID");

        Optional<Paquete> existenteOpt = paqueteDao.buscarPorUuid(paquete.getUuid());

        if (existenteOpt.isEmpty()) {
            throw new IllegalStateException("El paquete no existe");
        }

        Paquete existente = existenteOpt.get();

        if (existente.isEliminado()) {
            throw new IllegalStateException("No se puede modificar un paquete eliminado");
        }

        if (existente.getEstado() == EstadoPaquete.ENTREGADO) {
            throw new IllegalStateException("No se puede modificar un paquete ENTREGADO");
        }

        paqueteDao.actualizar(paquete);
    }

    // ============================
    // Borrado lógico
    // ============================
    @Override
    public void eliminarPaquete(String uuid) {

        validarCampoObligatorio(uuid, "UUID");

        Optional<Paquete> existenteOpt = paqueteDao.buscarPorUuid(uuid);

        if (existenteOpt.isEmpty()) {
            throw new IllegalStateException("El paquete no existe");
        }

        Paquete existente = existenteOpt.get();

        if (existente.isEliminado()) {
            throw new IllegalStateException("El paquete ya está eliminado");
        }

        paqueteDao.eliminarLogico(uuid);
    }

    // ============================
    // Validaciones comunes
    // ============================
    private void validarCampoObligatorio(String valor, String nombreCampo) {
        if (valor == null || valor.trim().isEmpty()) {
            throw new IllegalArgumentException(
                    "El campo " + nombreCampo + " es obligatorio"
            );
        }
    }
}
