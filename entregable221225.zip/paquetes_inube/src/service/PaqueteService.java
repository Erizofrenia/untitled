package service;

import model.Paquete;

import java.util.List;
import java.util.Optional;

public interface PaqueteService {

    Paquete registrarPaquete(String destinatario, String direccion);

    Optional<Paquete> buscarPorUuid(String uuid);

    List<Paquete> listarPaquetesActivos();

    void actualizarPaquete(Paquete paquete);

    void eliminarPaquete(String uuid);
}
