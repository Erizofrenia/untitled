package view;

import controller.PaqueteController;
import model.EstadoPaquete;
import model.Paquete;

import java.util.List;
import java.util.Optional;
import java.util.Scanner;

public class PaqueteView {

    private final PaqueteController controller;
    private final Scanner scanner;

    public PaqueteView() {
        this.controller = new PaqueteController();
        this.scanner = new Scanner(System.in);
    }

    // ============================
    // Inicio de la aplicación
    // ============================
    public void iniciar() {
        int opcion;

        do {
            mostrarMenu();
            opcion = leerOpcion();

            try {
                ejecutarOpcion(opcion);
            } catch (RuntimeException e) {
                System.out.println("❌ Error: " + e.getMessage());
            }

        } while (opcion != 6);

        System.out.println("Sistema finalizado. Hasta luego.");
    }

    // ============================
    // Menú principal
    // ============================
    private void mostrarMenu() {

        System.out.println("""
╔═════════════════════════════════════════════════════════════════════
║        ┌──────────────────────────────────────────────────────────┐            
║        │                                                        ○ │             
║        │        /\\_/\\                                          ___│             
║        │       ( o.o )     zZ                                 |   │             
║        │        > ^ <                                         |   │             
║        │      ──┐│ │┌──        ────────                       |   │             
║        │        ││ ││        ──        ──                     |   │             
║        │        ││ ││           ────────                      |   │             
║        │        ││ ││                                         |   │             
║        └────────┴┴─┴┴─────────────────────────────────────────┴───┘             
║              Miau paquetes INUBE Software               
╚═════════════════════════════════════════════════════════════════════
""");

        System.out.println("=== Sistema de Gestión de Paquetes (Inube) ===");
        System.out.println("1. Registrar paquete");
        System.out.println("2. Listar paquetes activos");
        System.out.println("3. Buscar paquete por UUID");
        System.out.println("4. Actualizar paquete");
        System.out.println("5. Eliminar paquete (borrado lógico)");
        System.out.println("6. Salir");
        System.out.print("Seleccione una opción: ");
    }


    // ============================
    // Lectura de opción segura
    // ============================
    private int leerOpcion() {
        try {
            int opcion = Integer.parseInt(scanner.nextLine());
            return opcion;
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    // ============================
    // Ejecución de opciones
    // ============================
    private void ejecutarOpcion(int opcion) {

        switch (opcion) {
            case 1 -> registrarPaquete();
            case 2 -> listarPaquetes();
            case 3 -> buscarPaquete();
            case 4 -> actualizarPaquete();
            case 5 -> eliminarPaquete();
            case 6 -> {
                // salir
            }
            default -> System.out.println("⚠️ Opción inválida");
        }
    }

    // ============================
    // Opción 1: Registrar
    // ============================
    private void registrarPaquete() {
        System.out.print("Destinatario: ");
        String destinatario = scanner.nextLine();

        System.out.print("Dirección: ");
        String direccion = scanner.nextLine();

        Paquete paquete = controller.crearPaquete(destinatario, direccion);

        System.out.println("✅ Paquete registrado correctamente");
        System.out.println(paquete);
    }

    // ============================
    // Opción 2: Listar activos
    // ============================
    private void listarPaquetes() {
        List<Paquete> paquetes = controller.listarPaquetes();

        if (paquetes.isEmpty()) {
            System.out.println("No hay paquetes activos");
            return;
        }

        paquetes.forEach(System.out::println);
    }

    // ============================
    // Opción 3: Buscar por UUID
    // ============================
    private void buscarPaquete() {
        System.out.print("Ingrese UUID del paquete: ");
        String uuid = scanner.nextLine();

        Optional<Paquete> paqueteOpt = controller.buscarPaquetePorUuid(uuid);

        if (paqueteOpt.isPresent()) {
            System.out.println(paqueteOpt.get());
        } else {
            System.out.println("Paquete no encontrado");
        }
    }

    // ============================
    // Opción 4: Actualizar
    // ============================
    private void actualizarPaquete() {
        System.out.print("UUID del paquete a actualizar: ");
        String uuid = scanner.nextLine();

        Optional<Paquete> paqueteOpt = controller.buscarPaquetePorUuid(uuid);

        if (paqueteOpt.isEmpty()) {
            System.out.println("Paquete no encontrado");
            return;
        }

        Paquete paquete = paqueteOpt.get();

        System.out.print("Nuevo destinatario: ");
        paquete.setDestinatario(scanner.nextLine());

        System.out.print("Nueva dirección: ");
        paquete.setDireccion(scanner.nextLine());

        System.out.print("Nuevo estado (REGISTRADO / EN_TRANSITO / ENTREGADO): ");
        String estadoInput = scanner.nextLine();

        try {
            paquete.setEstado(EstadoPaquete.valueOf(estadoInput));
        } catch (IllegalArgumentException e) {
            System.out.println("Estado inválido");
            return;
        }

        controller.actualizarPaquete(paquete);
        System.out.println("✅ Paquete actualizado correctamente");
    }

    // ============================
    // Opción 5: Borrado lógico
    // ============================
    private void eliminarPaquete() {
        System.out.print("UUID del paquete a eliminar: ");
        String uuid = scanner.nextLine();

        controller.eliminarPaqueteLogico(uuid);
        System.out.println("✅ Paquete eliminado lógicamente");
    }
}
