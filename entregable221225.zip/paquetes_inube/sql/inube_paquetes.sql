-----PAQUETES

CREATE TABLE PAQUETES (
    UUID            VARCHAR2(36)    NOT NULL,
    DESTINATARIO    VARCHAR2(100)   NOT NULL,
    DIRECCION       VARCHAR2(200)   NOT NULL,
    ESTADO          VARCHAR2(20)    NOT NULL,
    FECHA_REGISTRO  DATE            NOT NULL,
    ELIMINADO       NUMBER(1)       DEFAULT 0 NOT NULL,
    CONSTRAINT PK_PAQUETES PRIMARY KEY (UUID)
);

---- Documentación de la tabla

COMMENT ON TABLE PAQUETES IS
'Tabla que almacena los paquetes gestionados por el sistema de entrega de Inube.
Incluye información del destinatario, dirección, estado del paquete y control de borrado lógico.';

COMMENT ON COLUMN PAQUETES.UUID IS
'Identificador único del paquete (UUID) generado por la aplicación Java.';

COMMENT ON COLUMN PAQUETES.DESTINATARIO IS
'Nombre de la persona o entidad destinataria del paquete. Campo obligatorio.';

COMMENT ON COLUMN PAQUETES.DIRECCION IS
'Dirección completa de entrega del paquete. Campo obligatorio.';

COMMENT ON COLUMN PAQUETES.ESTADO IS
'Estado actual del paquete. Valores permitidos: REGISTRADO, EN_TRANSITO, ENTREGADO.';

COMMENT ON COLUMN PAQUETES.FECHA_REGISTRO IS
'Fecha y hora en que el paquete fue registrado en el sistema.';

COMMENT ON COLUMN PAQUETES.ELIMINADO IS
'Indicador de borrado lógico del paquete. 0 = activo, 1 = eliminado.';
